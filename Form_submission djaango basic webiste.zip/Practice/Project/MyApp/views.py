from django.shortcuts import render,HttpResponse
from MyApp.models import Contact
from django.contrib import messages
# Create your views here.
def index(request):
    # return HttpResponse("Hello django---This is my home page ")
    messages.success("Your form has been submitted---!")
    return render(request,'index.html')
def about(request):
    # return HttpResponse("Helllo django----- this is my about page")
    return render(request,'about.html')

def contact(request):
    # return HttpResponse("Helllo django----- this is my contact page")
    if request.method == 'POST':
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        password = request.POST.get('password')
        #Create object of Contact Class
        contactObj = Contact(first_name=first_name,last_name=last_name,email=email,password=password)
        contactObj.save()
        messages.success(request, " Your form has been submitted----!!.")

       

    return render(request,'contact.html')
def services(request):
    return render(request,'services.html')
