from django.contrib import admin
from MyApp.models import Contact#-->this is class name in models.py
# Register your models here.
admin.site.register(Contact)