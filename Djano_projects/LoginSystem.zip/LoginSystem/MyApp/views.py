from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import logout, authenticate, login
# shamii--->hello1122
# Ehtsham-->Khaliq1202
# Create your views here.


def index(request):
    if request.user.is_anonymous:
        print(request.user)
        # return redirect("/login")
        return render(request, 'index.html')
    return render(request, 'index.html')


def loginuser(request):
    if request.method == 'POST':
        username = method.POST.get('username')
        password = method.POST.get('password')
        user = authenticate(username=username, password="password")
        print(username, password)
        if user is not None:
            login(request, user)
            return redirect("/")
        else:
            return render(request, 'login.html')
    return render(request, 'login.html')


def logoutuser(request):
    logout(request)
    return redirect("/login")
