from django.contrib import admin
from django.urls import path
from MyApp import views

urlpatterns = [
    path("", views.index, name='Home'),
    path("add", views.add, name='Add'),
    path("edit", views.edit, name='edit'),
    path("update/<str:id>", views.update, name="update"),
    path("delete/<str:id>", views.Delete, name="delete")
]
