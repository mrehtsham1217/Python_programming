from flask import Flask,request,jsonify
#First step
from flask_restful import Api,Resource

app = Flask(__name__)
#2nd step
api = Api(app)
def checkPostedData(postedData,function_name):
    if function_name == "add" or function_name=="Subtraction" or function_name=="Multiplication":
        if "x" not in postedData or "y" not in postedData:
            return 301
        else:
            return 200
    elif function_name=="Division":
        if "x" not in postedData or "y" not in postedData:
            return 301
        elif (int(postedData["y"]) ==0):
            return 302
        else:
            return 200 
        
# -----classes----
class Add(Resource):
    def post(self):
        posted_data = request.get_json()
        status = checkPostedData(posted_data,"add")
        if status!=200:
            retAdd = {
                'Message ':"An Error has occurred",
                'Status code':status
            }
            return jsonify(retAdd)
        x = posted_data["x"]
        y = posted_data["y"]
        x = int(x)
        y = int(y)
        add = x+y
        retAdd = {
            'Message ':add,
            'Status code':200
        }
        return jsonify(retAdd)
    
    
class Subtraction(Resource):
    def post(self):
        posted_data = request.get_json()
        status = checkPostedData(posted_data,"Subtraction")
        if status!=200:
            retAdd = {
                'Message ':"There is some missing values",
                'Status code':status
            }
            return jsonify(retAdd)
        x = posted_data["x"]
        y = posted_data["y"]
        x = int(x)
        y = int(y)
        sub = x-y
        retSub = {
            'Message ':sub,
            'Status code':200
        }
        return jsonify(retSub)
class Division(Resource):
    def post(self):
        posted_data = request.get_json()
        status = checkPostedData(posted_data,"Division")
        if status!=200:
            retAdd = {
                'Message ':"There is some missing values",
                'Status code':status
            }
            return jsonify(retAdd)
        x = posted_data["x"]
        y = posted_data["y"]
        x = int(x)
        y = int(y)
        Division = x/y
        retSub = {
            'Message ':Division,
            'Status code':200
        }
        return jsonify(retSub)
class Multiplication(Resource):
    def post(self):
        posted_data = request.get_json()
        status = checkPostedData(posted_data,"Multiplication")
        if status!=200:
            retAdd = {
                'Message ':"There is some missing values",
                'Status code':status
            }
            return jsonify(retAdd)
        x = posted_data["x"]
        y = posted_data["y"]
        x = int(x)
        y = int(y)
        Multiply = x*y
        retSub = {
            'Message ':Multiply,
            'Status code':200
        }
        return jsonify(retSub)
#Route for first function
api.add_resource(Add,'/add')
api.add_resource(Subtraction, '/subtraction')
api.add_resource(Division, '/division')
api.add_resource(Multiplication, '/multiplication')


@app.route('/')
def hello():
    return 'Mr Ehtsham khaliq!'

if __name__=="__main__":
    app.run(host='0.0.0.0')