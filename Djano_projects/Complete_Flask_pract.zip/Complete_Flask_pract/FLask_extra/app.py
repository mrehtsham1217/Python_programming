from flask import Flask,render_template,request,flash
from flask_sqlalchemy import SQLAlchemy
import mysql.connector
app = Flask(__name__)
import os
app.secret_key = os.urandom(24)  # Generates a random secret key

connection = mysql.connector.connect(host='localhost',user='root',password='',
                                      database='login')
cursor = connection.cursor()

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/register')
def register():
    return render_template('registeration.html')
@app.route('/home')
def home():
    return "<h1>This is the home page</h1>"

@app.route('/validation',methods=['POST'])
def validation():
    email=request.form.get('email')
    password=request.form.get('password')
    print(email,password)
    cursor.execute("""SELECT * FROM `login_info` WHERE `user_email` LIKE '{}' AND `user_password` = '{}'""".format(email, password))
    users = cursor.fetchall()
    if len(users)>0:
        return render_template('home.html')
    else:
        return render_template('login.html')
@app.route('/add_user',methods=['POST'])
def add_user():
    name=request.form.get('uname')
    email=request.form.get('uemail')
    password=request.form.get('upassword')
    cursor.execute("""INSERT INTO `login_info` (`user_id`,`user_name`, `user_email`, `user_password`) VALUES (NULL, '{}', '{}', '{}')""".format(name, email, password))
    connection.commit()
    flash('User added successfully!', 'success')
    return "User added successfully"

    
if __name__=="__main__":
    app.run(debug=True)