from django.contrib import admin
from django.urls import path
from MyApp import views

urlpatterns = [
    path("", views.index, name='Home'),
    path("analyse", views.analyse, name='analyse'),
    # path("removepun", views.removepun, name='Remove'),
    # path("capfirst", views.capfirst, name='capfirst'),
    # path("Lineremove", views.Lineremove, name='Remove'),
    # path("spaceremove", views.spaceremove, name='spaceremove'),
    # path("charcount", views.charcount, name='charcount'),


]
