from django.shortcuts import render, HttpResponse, redirect

# Create your views here.


def index(request):
    # return HttpResponse("This is my home page")
    return render(request, 'index.html')


def analyse(request):
    djtext = request.GET.get('text', 'default')
    removepunc = request.GET.get('removepun', 'off')
    capital = request.GET.get('capital', 'off')
    small = request.GET.get('small', 'off')
    space = request.GET.get('space', 'off')
    extraspace = request.GET.get('Extraspace', 'off')
    line = request.GET.get('line', 'off')
    count = request.GET.get('Counter', 'off')

    print(djtext)
    print(removepunc)
    analyzed = ""
    punctuations = '''!@#$%^&*()_<>""[],';;%{},()~..'''

    if removepunc == 'on':
        for i in djtext:  # hello remove me:::""
            if i not in punctuations:
                analyzed = analyzed + i
        params = {'purpose': 'Remove Punctuations', 'analysed_text': analyzed}
        return render(request, 'analyse.html', params)

    elif (capital == 'on'):
        analyze = ""
        for char in djtext:
            analyze = analyze + char.upper()
        params = {'purpose': 'Capitalize Each Word',
                  'analysed_text': analyze}
        return render(request, 'analyse.html', params)

    elif (line == 'on'):
        analyze = ""
        for char in djtext:
            analyze = analyze + char.lower()
        params = {'purpose': 'Lower case Each Word',
                  'analysed_text': analyze}
        return render(request, 'analyse.html', params)
    elif (line == 'on'):
        analyse = ""
        for char in djtext:
            if char != "\n":
                analyse = analyse + char
        params = {'purpose': 'Line Remover Each Word',
                  'analysed_text': analyse}
        return render(request, 'analyse.html', params)
    elif (space == "on"):
        analyse = ""
        for char in djtext:
            if char != " ":
                analyse = analyse + char
        params = {'purpose': 'Space Remover Each Word',
                  'analysed_text': analyse}
        return render(request, 'analyse.html', params)
    elif (extraspace == "on"):
        analyzed = ""
        for index, char in enumerate(djtext):
            if djtext[index] == " " and djtext[index+1] == " ":
                pass
            else:
                analyzed = analyzed + char
        params = {'purpose': 'Extra Space Remover',
                  'analysed_text': analyzed}
        return render(request, 'analyse.html', params)
    elif (count == "on"):
        words = djtext.split()
        analyse = len(words)

        params = {'purpose': 'words counter',
                  'analysed_text': analyse}
        return render(request, 'analyse.html', params)

    else:
        return HttpResponse("You cannot use above functions")
    # return HttpResponse("hello")
